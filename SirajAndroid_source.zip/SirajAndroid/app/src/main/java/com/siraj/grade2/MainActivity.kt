package com.siraj.grade2

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.safeDrawing
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.EmojiEvents
import androidx.compose.material.icons.filled.FactCheck
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Ink = Color(0xFF183153)
private val Gold = Color(0xFFE7B653)
private val Sky = Color(0xFFE8F4FF)
private val Mint = Color(0xFFE4F6EC)
private val Cream = Color(0xFFFFF5DF)
private val Lilac = Color(0xFFF0EAFE)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme(
                colorScheme = lightColorScheme(
                    primary = Ink,
                    secondary = Gold,
                    background = Color(0xFFF7F9FC),
                    surface = Color.White
                )
            ) {
                SirajApp()
            }
        }
    }
}

private data class Feature(
    val title: String,
    val subtitle: String,
    val icon: ImageVector,
    val color: Color
)

@Composable
private fun SirajApp() {
    var mode by remember { mutableStateOf("student") }
    var selected by remember { mutableStateOf<String?>(null) }

    val features = if (mode == "student") listOf(
        Feature("اللغة العربية", "قراءة وفهم وإملاء", Icons.Filled.AutoStories, Sky),
        Feature("الرياضيات", "أعداد وعمليات ومسائل", Icons.Filled.Calculate, Mint),
        Feature("ألعاب تعليمية", "تعلّم باللعب والتحدي", Icons.Filled.SmartToy, Lilac),
        Feature("إنجازاتي", "تابع تقدّمك ونجومك", Icons.Filled.EmojiEvents, Cream)
    ) else listOf(
        Feature("تحضير الدروس", "أهداف وتمهيد وأنشطة وتقويم", Icons.Filled.MenuBook, Sky),
        Feature("متابعة الطلاب", "ملاحظات ومستويات الإتقان", Icons.Filled.School, Mint),
        Feature("الاختبارات", "أسئلة قصيرة وتقييم المهارات", Icons.Filled.FactCheck, Lilac),
        Feature("الأنشطة الصفية", "أفكار عملية للتعلّم", Icons.Filled.CheckCircle, Cream)
    )

    Surface(
        modifier = Modifier.fillMaxSize(),
        color = Color(0xFFF7F9FC)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(WindowInsets.safeDrawing.asPaddingValues())
                .padding(horizontal = 18.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column(horizontalAlignment = Alignment.Start) {
                    Text("سِراج", color = Ink, fontSize = 30.sp, fontWeight = FontWeight.ExtraBold)
                    Text("رفيق التعلّم • الصف الثاني", color = Color(0xFF64748B), fontSize = 13.sp)
                }
                Box(
                    modifier = Modifier
                        .background(Gold.copy(alpha = 0.22f), RoundedCornerShape(18.dp))
                        .padding(horizontal = 14.dp, vertical = 10.dp)
                ) {
                    Text("٢", color = Ink, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                }
            }

            Spacer(Modifier.height(18.dp))

            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(24.dp),
                colors = CardDefaults.cardColors(containerColor = Ink),
                elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
            ) {
                Column(Modifier.padding(20.dp), horizontalAlignment = Alignment.End) {
                    Text(
                        if (mode == "student") "أهلًا يا بطل!" else "أهلًا أستاذنا!",
                        color = Gold, fontSize = 23.sp, fontWeight = FontWeight.Bold,
                        textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(6.dp))
                    Text(
                        if (mode == "student") "هيا نتعلّم شيئًا جديدًا اليوم." else "كل أدوات صفّك في مكان واحد.",
                        color = Color.White, fontSize = 16.sp,
                        textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()
                    )
                    Spacer(Modifier.height(14.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        ModeButton("وضع الطالب", mode == "student") { mode = "student"; selected = null }
                        ModeButton("وضع المعلم", mode == "teacher") { mode = "teacher"; selected = null }
                    }
                }
            }

            Spacer(Modifier.height(18.dp))
            Text(
                if (mode == "student") "ماذا تريد أن تتعلّم؟" else "ماذا سننجز اليوم؟",
                color = Ink, fontSize = 20.sp, fontWeight = FontWeight.Bold,
                textAlign = TextAlign.End, modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier.weight(1f).fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(features) { feature ->
                    FeatureCard(feature = feature, onClick = { selected = feature.title })
                }
            }

            if (selected != null) {
                Card(
                    modifier = Modifier.fillMaxWidth().padding(top = 10.dp),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White)
                ) {
                    Column(
                        modifier = Modifier.fillMaxWidth().padding(16.dp),
                        horizontalAlignment = Alignment.End
                    ) {
                        Text(selected!!, color = Ink, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(5.dp))
                        Text(
                            "هذا القسم جاهز للتطوير في الخطوات القادمة، وسنضيف محتواه وفق المنهاج السوري للصف الثاني.",
                            color = Color(0xFF53657D), textAlign = TextAlign.End, fontSize = 14.sp
                        )
                        Spacer(Modifier.height(8.dp))
                        Button(onClick = { selected = null }) { Text("العودة إلى الرئيسية") }
                    }
                }
            }

            Spacer(Modifier.height(8.dp))
            Text(
                "يعمل التصميم الأولي دون اتصال بالإنترنت",
                color = Color(0xFF718096), fontSize = 12.sp, textAlign = TextAlign.Center
            )
        }
    }
}

@Composable
private fun ModeButton(label: String, active: Boolean, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        colors = ButtonDefaults.buttonColors(
            containerColor = if (active) Gold else Color.White,
            contentColor = if (active) Ink else Color.White
        ),
        shape = RoundedCornerShape(14.dp)
    ) {
        Text(label, fontWeight = FontWeight.Bold, fontSize = 13.sp)
    }
}

@Composable
private fun FeatureCard(feature: Feature, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(142.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = feature.color),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(
            modifier = Modifier.fillMaxSize().padding(14.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.SpaceBetween
        ) {
            Icon(feature.icon, contentDescription = null, tint = Ink)
            Column(horizontalAlignment = Alignment.End) {
                Text(feature.title, color = Ink, fontSize = 16.sp, fontWeight = FontWeight.Bold, textAlign = TextAlign.End)
                Spacer(Modifier.height(3.dp))
                Text(feature.subtitle, color = Color(0xFF53657D), fontSize = 11.sp, textAlign = TextAlign.End, lineHeight = 15.sp)
            }
        }
    }
}
